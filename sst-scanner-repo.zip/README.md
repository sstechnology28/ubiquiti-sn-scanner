# SST SN Scanner (Ubiquiti serial/MAC inventory PWA)

Live: https://scanner.specializedsecuritytechnology.com
Server: srv1542704 (Hostinger VPS), folder /opt/sst-scanner, behind Traefik + Cloudflare.

App files are in `site/`. Data is stored only in each phone's browser (IndexedDB); the server only serves static files.

## Deploy / update
    cd /opt/sst-scanner && git pull && docker compose up -d --build

## Remove
    cd /opt/sst-scanner && docker compose down
