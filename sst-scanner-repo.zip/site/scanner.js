// High-resolution barcode scanner: native BarcodeDetector (Android Chrome) + ZXing fallback.
(function(){
  const ZX=window.ZXing;
  const NATIVE_FORMATS=["qr_code","data_matrix","code_128","code_39","code_93","ean_13","ean_8","upc_a","upc_e","itf","codabar","pdf417","aztec"];
  const NATIVE_TO_NAME={qr_code:"QR_CODE",data_matrix:"DATA_MATRIX",code_128:"CODE_128",code_39:"CODE_39",code_93:"CODE_93",ean_13:"EAN_13",ean_8:"EAN_8",upc_a:"UPC_A",upc_e:"UPC_E",itf:"ITF",codabar:"CODABAR",pdf417:"PDF_417",aztec:"AZTEC"};
  let native=null, zx=null, nativeReady=null;
  async function initNative(){
    if(!("BarcodeDetector" in window)) return null;
    try{const sup=await BarcodeDetector.getSupportedFormats();const f=NATIVE_FORMATS.filter(x=>sup.includes(x));if(!f.length)return null;native=new BarcodeDetector({formats:f});return native;}catch(e){return null;}
  }
  function initZx(){
    if(zx||!ZX) return zx;
    const hints=new Map();const F=ZX.BarcodeFormat;
    hints.set(ZX.DecodeHintType.POSSIBLE_FORMATS,[F.QR_CODE,F.DATA_MATRIX,F.CODE_128,F.CODE_39,F.CODE_93,F.EAN_13,F.EAN_8,F.UPC_A,F.UPC_E,F.ITF,F.CODABAR,F.PDF_417,F.AZTEC]);
    hints.set(ZX.DecodeHintType.TRY_HARDER,true);
    zx=new ZX.MultiFormatReader();zx.setHints(hints);return zx;
  }
  function zxDecode(canvas){
    initZx(); if(!zx) return null;
    try{
      const src=new ZX.HTMLCanvasElementLuminanceSource(canvas);
      const r=zx.decodeWithState(new ZX.BinaryBitmap(new ZX.HybridBinarizer(src)));
      return {text:r.getText(),format:ZX.BarcodeFormat[r.getBarcodeFormat()]};
    }catch(e){ return null; }
  }
  async function decodeCanvas(canvas){
    if(nativeReady===null) nativeReady=initNative();
    const nd=await nativeReady;
    if(nd){
      try{const res=await nd.detect(canvas); if(res&&res.length){
        // Prefer the code nearest the centre
        const cx=canvas.width/2,cy=canvas.height/2;
        res.sort((a,b)=>Math.hypot(a.boundingBox.x+a.boundingBox.width/2-cx,a.boundingBox.y+a.boundingBox.height/2-cy)-Math.hypot(b.boundingBox.x+b.boundingBox.width/2-cx,b.boundingBox.y+b.boundingBox.height/2-cy));
        return {text:res[0].rawValue,format:NATIVE_TO_NAME[res[0].format]||res[0].format,all:res.map(r=>({text:r.rawValue,format:NATIVE_TO_NAME[r.format]||r.format}))};
      }}catch(e){}
    }
    return zxDecode(canvas);
  }
  class Scanner{
    constructor(container,onResult){this.c=container;this.onResult=onResult;this.stream=null;this.running=false;this.busy=false;this.canvas=document.createElement("canvas");this.ctx=this.canvas.getContext("2d",{willReadFrequently:true});this.frame=0;}
    async start(deviceId){
      await this.stop();
      const base={width:{ideal:1920},height:{ideal:1080},advanced:[{focusMode:"continuous"}]};
      const video=deviceId?{...base,deviceId:{exact:deviceId}}:{...base,facingMode:{ideal:"environment"}};
      this.stream=await navigator.mediaDevices.getUserMedia({video,audio:false});
      this.track=this.stream.getVideoTracks()[0];
      this.c.innerHTML=`<div class="cam-wrap"><video playsinline muted autoplay></video><div class="cam-box"><i></i><i></i><i></i><i></i><div class="cam-line"></div></div><div class="cam-hint">Fit the barcode inside the box</div></div>`;
      this.video=this.c.querySelector("video");this.video.srcObject=this.stream;
      await this.video.play().catch(()=>{});
      await new Promise(r=>{if(this.video.videoWidth)r();else this.video.onloadedmetadata=()=>r();});
      this.running=true;this.loop();
      return this.capabilities();
    }
    capabilities(){try{return this.track.getCapabilities?this.track.getCapabilities():{};}catch(e){return {};}}
    async setTorch(on){await this.track.applyConstraints({advanced:[{torch:!!on}]});}
    async setZoom(z){await this.track.applyConstraints({advanced:[{zoom:z}]});}
    loop(){
      if(!this.running) return;
      const tick=async()=>{
        if(!this.running) return;
        if(!this.busy && this.video.readyState>=2){
          this.busy=true;
          try{
            const vw=this.video.videoWidth,vh=this.video.videoHeight;
            // Crop the centre box (matches .cam-box: 90% wide, 46% tall); alternate frames scan the full frame
            const full=(this.frame++%4===3);
            const cw=full?vw:Math.round(vw*0.9), ch=full?vh:Math.round(vh*0.46);
            const sx=Math.round((vw-cw)/2), sy=Math.round((vh-ch)/2);
            const scale=Math.min(1,1600/cw);
            this.canvas.width=Math.round(cw*scale);this.canvas.height=Math.round(ch*scale);
            this.ctx.drawImage(this.video,sx,sy,cw,ch,0,0,this.canvas.width,this.canvas.height);
            const r=await decodeCanvas(this.canvas);
            if(r&&r.text&&this.running) this.onResult(r.text,r.format,r.all);
          }catch(e){}
          this.busy=false;
        }
        if(this.running) this.raf=setTimeout(tick,90);
      };
      tick();
    }
    async stop(){
      this.running=false;clearTimeout(this.raf);
      if(this.stream){this.stream.getTracks().forEach(t=>t.stop());this.stream=null;}
      if(this.c) this.c.innerHTML="";
    }
    static async cameras(){try{const d=await navigator.mediaDevices.enumerateDevices();return d.filter(x=>x.kind==="videoinput");}catch(e){return [];}}
    static async decodeFile(file){
      const url=URL.createObjectURL(file);
      try{
        const img=await new Promise((res,rej)=>{const i=new Image();i.onload=()=>res(i);i.onerror=rej;i.src=url;});
        const tries=[1,0.5,0.25].map(s=>Math.min(1,2400/Math.max(img.width,img.height))*s);
        if(Math.max(img.width,img.height)<1200) tries.unshift(1);
        for(const s of tries){
          const c=document.createElement("canvas");c.width=Math.max(1,Math.round(img.width*s));c.height=Math.max(1,Math.round(img.height*s));
          c.getContext("2d").drawImage(img,0,0,c.width,c.height);
          const r=await decodeCanvas(c); if(r) return r;
          // try rotated 90°
          const c2=document.createElement("canvas");c2.width=c.height;c2.height=c.width;const x=c2.getContext("2d");x.translate(c2.width/2,c2.height/2);x.rotate(Math.PI/2);x.drawImage(c,-c.width/2,-c.height/2);
          const r2=await decodeCanvas(c2); if(r2) return r2;
        }
        return null;
      } finally { URL.revokeObjectURL(url); }
    }
  }
  window.SNScanner=Scanner;
})();
