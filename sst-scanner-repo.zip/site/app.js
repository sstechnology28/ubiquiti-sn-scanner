(function(){
"use strict";
const APP_VERSION="1.0.0";
const $=s=>document.querySelector(s), $$=s=>Array.from(document.querySelectorAll(s));
const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,8);
const esc=s=>String(s==null?"":s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const pad=n=>String(n).padStart(2,"0");
const toLocalInput=d=>{d=new Date(d);return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;};
const fmtDate=d=>{if(!d)return"";d=new Date(d);return d.toLocaleString(undefined,{year:"numeric",month:"short",day:"numeric",hour:"numeric",minute:"2-digit"});};
const fmtDay=d=>new Date(d).toLocaleDateString(undefined,{year:"numeric",month:"long",day:"numeric"});
const fileStamp=()=>{const d=new Date();return `${d.getFullYear()}${pad(d.getMonth()+1)}${pad(d.getDate())}-${pad(d.getHours())}${pad(d.getMinutes())}`;};
const slug=s=>String(s||"export").replace(/[^a-z0-9]+/gi,"-").replace(/^-|-$/g,"").slice(0,40)||"export";

const DEFAULT_SETTINGS={company:"Specialized Security Technology",phone:"",email:"",website:"specializedsecuritytechnology.com",address:"",installer:"",footer:"Devices listed above were scanned and recorded at the time of installation.",logo:"",theme:"auto",beep:true,vibrate:true,serialFromMac:true,customModels:"",activeProjectId:"",continuous:false,keepFields:true};
const S={settings:{...DEFAULT_SETTINGS},projects:[],devices:[],editingId:null,photo:"",raw:"",scanner:null,scanning:false,lastText:"",lastAt:0,torch:false,deferredInstall:null};

// ---------- utils ----------
function toast(msg,kind="ok",ms=2600){const t=$("#toast");t.textContent=msg;t.className="toast "+kind;t.hidden=false;clearTimeout(toast._t);toast._t=setTimeout(()=>t.hidden=true,ms);}
let audioCtx=null;
function beep(ok=true){
  if(!S.settings.beep) return;
  try{audioCtx=audioCtx||new (window.AudioContext||window.webkitAudioContext)();const o=audioCtx.createOscillator(),g=audioCtx.createGain();
    o.type="square";o.frequency.value=ok?1800:420;g.gain.setValueAtTime(0.08,audioCtx.currentTime);g.gain.exponentialRampToValueAtTime(0.0001,audioCtx.currentTime+(ok?0.12:0.35));
    o.connect(g);g.connect(audioCtx.destination);o.start();o.stop(audioCtx.currentTime+(ok?0.13:0.36));}catch(e){}
}
function buzz(p){ if(S.settings.vibrate && navigator.vibrate) navigator.vibrate(p); }
function modal({title,body,actions}){
  return new Promise(resolve=>{
    $("#modalTitle").textContent=title||"";
    const b=$("#modalBody"); b.innerHTML=""; if(typeof body==="string") b.innerHTML=body; else if(body) b.appendChild(body);
    const a=$("#modalActions"); a.innerHTML="";
    (actions||[{label:"OK",value:true,cls:"primary"}]).forEach(ac=>{const btn=document.createElement("button");btn.className="btn "+(ac.cls||"");btn.textContent=ac.label;
      btn.onclick=()=>{ if(ac.validate && !ac.validate()) return; close(ac.value);} ;a.appendChild(btn);});
    const m=$("#modal"); m.hidden=false;
    function close(v){m.hidden=true;$("#modalClose").onclick=null;m.onclick=null;resolve(v);}
    $("#modalClose").onclick=()=>close(null);
    m.onclick=e=>{if(e.target===m) close(null);};
  });
}
const confirmBox=(title,msg,okLabel="Delete",cls="danger solid")=>modal({title,body:`<p>${msg}</p>`,actions:[{label:"Cancel",value:false},{label:okLabel,value:true,cls}]});
function readFileAsDataURL(f){return new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(r.result);r.onerror=rej;r.readAsDataURL(f);});}
function readFileAsText(f){return new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(r.result);r.onerror=rej;r.readAsText(f);});}
async function compressImage(file,max=1280,q=0.72){
  const url=await readFileAsDataURL(file);
  return new Promise(res=>{const img=new Image();img.onload=()=>{const s=Math.min(1,max/Math.max(img.width,img.height));const c=document.createElement("canvas");
    c.width=Math.round(img.width*s);c.height=Math.round(img.height*s);c.getContext("2d").drawImage(img,0,0,c.width,c.height);res(c.toDataURL("image/jpeg",q));};img.onerror=()=>res(url);img.src=url;});
}

// ---------- data ----------
async function load(){
  const st=await DB.get("kv","settings"); if(st) S.settings={...DEFAULT_SETTINGS,...st};
  S.projects=(await DB.all("projects")).sort((a,b)=>(b.updatedAt||0)-(a.updatedAt||0));
  S.devices=await DB.all("devices");
  window.CUSTOM_MODELS=S.settings.customModels.split("\n").map(s=>s.trim()).filter(Boolean);
}
const saveSettings=()=>DB.put("kv",S.settings,"settings");
const project=id=>S.projects.find(p=>p.id===id);
const projLabel=p=>p?(p.client+(p.site?" · "+p.site:"")):"Unassigned";
const devicesOf=pid=>S.devices.filter(d=>pid==="__all"?true:(pid==="__none"?!d.projectId:d.projectId===pid));
function findDuplicate(serial,mac,exceptId){
  const sn=(serial||"").toUpperCase(), m=(mac||"").toUpperCase();
  return S.devices.find(d=>d.id!==exceptId && ((sn && (d.serial||"").toUpperCase()===sn) || (m && (d.mac||"").toUpperCase()===m)));
}

// ---------- theme / branding ----------
function applyTheme(){
  const t=S.settings.theme; const dark=t==="dark"||(t==="auto"&&matchMedia("(prefers-color-scheme: dark)").matches);
  document.documentElement.dataset.theme=dark?"dark":"light";
  document.querySelector('meta[name="theme-color"]').content=dark?"#0b1220":"#f3f6fb";
}
function applyBrand(){
  $("#brandName").textContent=S.settings.company||"SN Scanner";
  const l=$("#brandLogo"); if(S.settings.logo){l.src=S.settings.logo;l.hidden=false;} else l.hidden=true;
}

// ---------- pickers ----------
function fillSelect(sel,opts,value){sel.innerHTML=opts.map(o=>`<option value="${esc(o.value)}">${esc(o.label)}</option>`).join("");if(value!==undefined)sel.value=value;}
function refreshPicklists(){
  const models=window.UBNT_MODELS.map(m=>m[0]).concat(window.CUSTOM_MODELS);
  const seen=new Set();$("#modelList").innerHTML=models.filter(m=>!seen.has(m)&&seen.add(m)).map(m=>`<option value="${esc(m)}">`).join("");
  const locs=[...new Set(S.devices.map(d=>d.location).filter(Boolean))].sort();
  $("#locationList").innerHTML=locs.map(l=>`<option value="${esc(l)}">`).join("");
  fillSelect($("#fType"),[{value:"",label:"Select type…"}].concat(window.UBNT_TYPES.map(t=>({value:t,label:t}))),$("#fType").value);
  fillSelect($("#fStatus"),window.UBNT_STATUSES.map(t=>({value:t,label:t})),$("#fStatus").value||"Installed");
  const pOpts=S.projects.map(p=>({value:p.id,label:projLabel(p)}));
  fillSelect($("#filterProject"),[{value:"__all",label:"All projects"}].concat(pOpts,[{value:"__none",label:"Unassigned"}]),$("#filterProject").value||"__all");
  fillSelect($("#filterType"),[{value:"",label:"All types"}].concat(window.UBNT_TYPES.map(t=>({value:t,label:t}))),$("#filterType").value);
  fillSelect($("#filterStatus"),[{value:"",label:"All statuses"}].concat(window.UBNT_STATUSES.map(t=>({value:t,label:t}))),$("#filterStatus").value);
  const ev=$("#exportProject").value||S.settings.activeProjectId||"__all";
  fillSelect($("#exportProject"),pOpts.concat([{value:"__all",label:"All devices (every project)"},{value:"__none",label:"Unassigned devices"}]),ev);
  if(!$("#exportProject").value) $("#exportProject").value="__all";
}
function refreshHeader(){
  const p=project(S.settings.activeProjectId);
  $("#projectPillText").textContent=p?projLabel(p):"Choose project";
  $("#projectPill").classList.toggle("none",!p);
  $("#deviceCount").textContent=S.devices.length;
}
function refreshAll(){refreshPicklists();refreshHeader();renderDevices();renderProjects();renderExportStats();}

// ---------- views ----------
function show(view){
  $$(".view").forEach(v=>v.hidden=v.id!=="view-"+view);
  $$(".tabbar button").forEach(b=>b.classList.toggle("active",b.dataset.view===view));
  if(view!=="scan" && S.scanning) stopScan();
  if(view==="devices") renderDevices(); if(view==="projects") renderProjects(); if(view==="export") renderExportStats(); if(view==="settings") renderSettings();
  window.scrollTo({top:0});
}

// ---------- form ----------
function clearForm(keep){
  const keepModel=keep&&S.settings.keepFields;
  const m=$("#fModel").value,t=$("#fType").value,l=$("#fLocation").value,st=$("#fStatus").value;
  ["#fSerial","#fMac","#fNotes"].forEach(s=>$(s).value="");
  if(!keepModel){$("#fModel").value="";$("#fType").value="";$("#fLocation").value="";$("#fStatus").value="Installed";} else {$("#fModel").value=m;$("#fType").value=t;$("#fLocation").value=l;$("#fStatus").value=st||"Installed";}
  $("#fInstaller").value=S.settings.installer||"";
  $("#fDate").value=toLocalInput(new Date());
  setPhoto(""); S.raw=""; $("#fRaw").textContent=""; S.editingId=null;
  $("#formTitle").textContent="Device details"; $("#btnSave").textContent="Save device";
}
function setPhoto(d){S.photo=d||"";const p=$("#fPhotoPreview");p.hidden=!d;if(d)p.src=d;$("#btnRemovePhoto").hidden=!d;}
function formData(){
  let serial=$("#fSerial").value.trim().toUpperCase(); const mac=UBNTParser.normMac($("#fMac").value)||$("#fMac").value.trim().toUpperCase();
  if(!serial && mac && S.settings.serialFromMac) serial=mac.replace(/:/g,"");
  return {serial,mac,model:$("#fModel").value.trim(),type:$("#fType").value,location:$("#fLocation").value.trim(),status:$("#fStatus").value||"Installed",
    installer:$("#fInstaller").value.trim(),scannedAt:$("#fDate").value?new Date($("#fDate").value).getTime():Date.now(),notes:$("#fNotes").value.trim(),photo:S.photo,raw:S.raw};
}
async function ensureProject(){
  if(project(S.settings.activeProjectId)) return S.settings.activeProjectId;
  const r=await pickProject(true); return r||"";
}
async function saveDevice(opts={}){
  const data=formData();
  if(!data.serial && !data.mac){toast("Enter or scan a serial number or MAC first","warn");$("#fSerial").focus();return false;}
  const editing=S.editingId?S.devices.find(d=>d.id===S.editingId):null;
  const dup=findDuplicate(data.serial,data.mac,editing&&editing.id);
  if(dup){
    beep(false);buzz([80,60,80]);
    if(opts.silentDup){showLast(`Duplicate: ${dup.serial||dup.mac} already in ${esc(projLabel(project(dup.projectId)))}`,true);return false;}
    const r=await modal({title:"Duplicate device",body:`<p>This device is already saved:</p><p class="mono"><b>${esc(dup.serial||"")}</b> ${esc(dup.mac||"")}</p><p class="muted">${esc(dup.model||"")} · ${esc(projLabel(project(dup.projectId)))} · ${esc(fmtDate(dup.scannedAt))}</p>`,
      actions:[{label:"Cancel",value:"cancel"},{label:"Open existing",value:"open"},{label:"Save anyway",value:"save",cls:"primary"}]});
    if(r==="open"){editDevice(dup.id);return false;} if(r!=="save") return false;
  }
  if(data.model && !data.type){const fm=UBNTParser.findModel(data.model);if(fm) data.type=fm.type;}
  let rec;
  if(editing){ rec={...editing,...data,updatedAt:Date.now()}; }
  else{ const pid=await ensureProject(); rec={id:uid(),projectId:pid,...data,createdAt:Date.now(),updatedAt:Date.now()}; }
  await DB.put("devices",rec);
  const i=S.devices.findIndex(d=>d.id===rec.id); if(i>=0) S.devices[i]=rec; else S.devices.push(rec);
  if(rec.projectId){const p=project(rec.projectId);if(p){p.updatedAt=Date.now();DB.put("projects",p);}}
  if(!editing){beep(true);buzz(60);}
  showLast(`${editing?"Updated":"Saved"}: <b class="mono">${esc(rec.serial||rec.mac)}</b> ${esc(rec.model||"")} → ${esc(projLabel(project(rec.projectId)))}`);
  toast(editing?"Device updated":"Device saved","ok",1500);
  clearForm(!editing); refreshAll();
  if(editing) show("devices");
  return true;
}
function showLast(html,dup){const l=$("#lastScan");l.innerHTML=html;l.classList.toggle("dup",!!dup);l.hidden=false;}

// ---------- scanning ----------
function onDecoded(text,fmt){
  const now=Date.now();
  if(text===S.lastText && now-S.lastAt<2500) return; // debounce same code
  S.lastText=text;S.lastAt=now;
  const w=document.querySelector(".cam-wrap"); if(w){w.classList.add("hit");setTimeout(()=>w.classList.remove("hit"),400);}
  handleScan(text,fmt||"");
}
function handleScan(text,fmt){
  const p=UBNTParser.parse(text,fmt);
  S.raw=(S.raw?S.raw+"\n":"")+(fmt?`[${fmt}] `:"")+text; $("#fRaw").textContent=S.raw;
  if(p.kind==="upc"){beep(false);buzz(200);showLast(`That is the product UPC barcode (${esc(p.upc)}), not the serial. Scan the barcode next to S/N or MAC.`,true);return;}
  if(p.kind==="unknown"){
    // Unknown text: put it in serial if short, else notes
    if(/^[A-Z0-9\-]{4,32}$/i.test(text)) p.serial=text.toUpperCase(); else {beep(false);showLast(`Scanned text not recognized: <span class="mono">${esc(text.slice(0,80))}</span> (saved under Raw data)`,true);return;}
  }
  // Merge into form (fill empty fields, or replace when a new serial/MAC arrives)
  const newIdentity=(p.serial||p.mac);
  if(newIdentity && ($("#fSerial").value||$("#fMac").value) && !S.editingId){
    const curMac=UBNTParser.normMac($("#fMac").value), curSn=$("#fSerial").value.toUpperCase();
    const same=(p.mac && p.mac===curMac) || (p.serial && p.serial===curSn) || (p.serial && curMac && p.serial===curMac.replace(/:/g,""));
    if(!same && !(p.serial && !p.mac && !curSn) && !(p.mac && !p.serial && !curMac)){ $("#fSerial").value="";$("#fMac").value=""; }
  }
  if(p.serial) $("#fSerial").value=p.serial;
  if(p.mac) $("#fMac").value=p.mac;
  if(!p.serial && p.mac && S.settings.serialFromMac && !$("#fSerial").value) $("#fSerial").value=p.mac.replace(/:/g,"");
  if(p.model){$("#fModel").value=p.model; if(p.type) $("#fType").value=p.type;}
  const dateCode=(text.match(/\b(\d{4})[A-Z]?\b/)||[])[1];
  if(p.kind==="model"){beep(true);buzz(40);showLast(`Model set: <b>${esc(p.model)}</b>. Now scan the serial / MAC barcode.`);return;}
  const dup=findDuplicate($("#fSerial").value,$("#fMac").value,S.editingId);
  if(S.settings.continuous && !S.editingId){ saveDevice({silentDup:true}); return; }
  if(dup){beep(false);buzz([80,60,80]);showLast(`Already saved: <b class="mono">${esc(dup.serial||dup.mac)}</b> in ${esc(projLabel(project(dup.projectId)))}. Saving again will ask to confirm.`,true);}
  else {beep(true);buzz(60);showLast(`Scanned <b class="mono">${esc($("#fSerial").value||$("#fMac").value)}</b>${p.model?" · "+esc(p.model):""}. Review and tap Save.`);}
}
async function startScan(){
  if(!window.isSecureContext||!navigator.mediaDevices){toast("Camera needs HTTPS. Open the app from its https link.","bad",4000);return;}
  try{
    if(!S.scanner) S.scanner=new SNScanner($("#reader"),onDecoded);
    const camSel=$("#cameraSelect");
    const caps=await S.scanner.start(camSel.value||undefined);
    S.scanning=true;$("#readerIdle").hidden=true;$("#btnStartScan").hidden=true;$("#btnStopScan").hidden=false;
    $("#btnTorch").hidden=!(caps&&caps.torch);
    if(caps&&caps.zoom&&caps.zoom.max>1){const z=$("#zoom");z.min=caps.zoom.min||1;z.max=Math.min(caps.zoom.max,8);z.step=caps.zoom.step||0.1;z.value=z.min;$("#zoomVal").textContent=Number(z.value).toFixed(1)+"×";$("#zoomRow").hidden=false;} else $("#zoomRow").hidden=true;
    const cams=await SNScanner.cameras();
    if(cams.length>1){fillSelect(camSel,[{value:"",label:"Back camera (auto)"}].concat(cams.map((c,i)=>({value:c.deviceId,label:c.label||("Camera "+(i+1))}))),camSel.value);camSel.hidden=false;}
  }catch(err){
    S.scanning=false;
    const msg=String(err&&(err.name+": "+err.message)||err);
    if(/Permission|NotAllowed/i.test(msg)) toast("Camera permission denied. Tap the lock icon in Chrome's address bar and allow Camera.","bad",6000);
    else if(/NotFound|Overconstrained/i.test(msg)) toast("No usable camera found. Pick another camera or use From photo.","bad",5000);
    else toast("Could not start camera: "+msg.slice(0,120),"bad",5000);
  }
}
async function stopScan(){
  if(S.scanner) await S.scanner.stop();
  S.scanning=false;S.torch=false;$("#readerIdle").hidden=false;$("#btnStartScan").hidden=false;$("#btnStopScan").hidden=true;$("#btnTorch").hidden=true;$("#zoomRow").hidden=true;
}
async function toggleTorch(){
  if(!S.scanner) return; S.torch=!S.torch;
  try{await S.scanner.setTorch(S.torch);}catch(e){S.torch=false;toast("Flashlight not supported on this camera","warn");}
}
async function scanFromFile(file){
  if(!file) return;
  toast("Reading barcode from photo…","ok",1500);
  const r=await SNScanner.decodeFile(file);
  if(r){ S.lastText="";handleScan(r.text,r.format); }
  else {beep(false);toast("No barcode found in that photo. Try closer, sharper, and with good light.","warn",4000);}
}

// ---------- devices list ----------
function filteredDevices(){
  const q=$("#search").value.trim().toLowerCase(), fp=$("#filterProject").value||"__all", ft=$("#filterType").value, fs=$("#filterStatus").value, sort=$("#sortBy").value;
  let list=devicesOf(fp).filter(d=>(!ft||d.type===ft)&&(!fs||d.status===fs));
  if(q){const qq=q.replace(/[:\-]/g,"");list=list.filter(d=>{const p=project(d.projectId);return [d.serial,d.mac,(d.mac||"").replace(/:/g,""),d.model,d.type,d.location,d.notes,d.installer,d.status,p&&p.client,p&&p.site].join(" ").toLowerCase().includes(q)||(qq&&(d.mac||"").replace(/:/g,"").toLowerCase().includes(qq));});}
  const cmp={"date-desc":(a,b)=>b.scannedAt-a.scannedAt,"date-asc":(a,b)=>a.scannedAt-b.scannedAt,model:(a,b)=>(a.model||"").localeCompare(b.model||"")||a.scannedAt-b.scannedAt,location:(a,b)=>(a.location||"").localeCompare(b.location||""),serial:(a,b)=>(a.serial||"").localeCompare(b.serial||"")}[sort];
  return list.sort(cmp);
}
function renderDevices(){
  const list=filteredDevices(); const box=$("#deviceList");
  $("#listSummary").textContent=`${list.length} of ${S.devices.length} devices`;
  if(!list.length){box.innerHTML=`<div class="empty">${S.devices.length?"No devices match these filters.":"No devices yet. Go to Scan to add your first one."}</div>`;return;}
  box.innerHTML=list.slice(0,500).map(d=>`<div class="dev" data-id="${d.id}">
    ${d.photo?`<img class="thumb" src="${d.photo}" alt="">`:""}
    <div class="dev-main">
      <div class="dev-top"><span class="dev-model">${esc(d.model||"Unknown model")}</span><span class="tag s-${esc(d.status)}">${esc(d.status||"")}</span></div>
      <div class="dev-sn">S/N ${esc(d.serial||"—")}${d.mac&&d.mac.replace(/:/g,"")!==d.serial?` · MAC ${esc(d.mac)}`:""}</div>
      <div class="dev-meta"><span>${esc(projLabel(project(d.projectId)))}</span>${d.location?`<span>📍 ${esc(d.location)}</span>`:""}<span>${esc(fmtDate(d.scannedAt))}</span>${d.installer?`<span>👤 ${esc(d.installer)}</span>`:""}</div>
    </div></div>`).join("")+(list.length>500?`<div class="empty">Showing first 500. Use search to narrow down.</div>`:"");
}
function editDevice(id){
  const d=S.devices.find(x=>x.id===id); if(!d) return;
  const body=document.createElement("div");
  const pOpts=S.projects.map(p=>`<option value="${p.id}" ${p.id===d.projectId?"selected":""}>${esc(projLabel(p))}</option>`).join("");
  body.innerHTML=`
   ${d.photo?`<img src="${d.photo}" style="width:100%;max-height:220px;object-fit:contain;border-radius:10px;margin-bottom:10px;background:#000">`:""}
   <div class="grid2">
    <label class="field"><span>Serial</span><input class="input mono" id="eSerial" value="${esc(d.serial)}"></label>
    <label class="field"><span>MAC</span><input class="input mono" id="eMac" value="${esc(d.mac)}"></label>
    <label class="field"><span>Model</span><input class="input" id="eModel" list="modelList" value="${esc(d.model)}"></label>
    <label class="field"><span>Type</span><select class="input" id="eType">${["",...window.UBNT_TYPES].map(t=>`<option ${t===d.type?"selected":""} value="${esc(t)}">${esc(t||"—")}</option>`).join("")}</select></label>
    <label class="field"><span>Location</span><input class="input" id="eLocation" list="locationList" value="${esc(d.location)}"></label>
    <label class="field"><span>Status</span><select class="input" id="eStatus">${window.UBNT_STATUSES.map(t=>`<option ${t===d.status?"selected":""}>${t}</option>`).join("")}</select></label>
    <label class="field"><span>Installer</span><input class="input" id="eInstaller" value="${esc(d.installer)}"></label>
    <label class="field"><span>Date / time</span><input class="input" type="datetime-local" id="eDate" value="${toLocalInput(d.scannedAt)}"></label>
   </div>
   <label class="field"><span>Project</span><select class="input" id="eProject"><option value="">Unassigned</option>${pOpts}</select></label>
   <label class="field"><span>Notes</span><textarea class="input" id="eNotes" rows="2">${esc(d.notes)}</textarea></label>
   <div class="photo-row"><label class="btn small">🖼️ ${d.photo?"Replace":"Add"} photo<input type="file" id="ePhoto" accept="image/*" capture="environment" hidden></label>${d.photo?`<button class="btn ghost small" id="eRemovePhoto">Remove photo</button>`:""}</div>
   ${d.raw?`<details class="raw"><summary>Raw scanned data</summary><pre class="mono">${esc(d.raw)}</pre></details>`:""}`;
  let newPhoto=d.photo;
  body.querySelector("#ePhoto").onchange=async e=>{if(e.target.files[0]){newPhoto=await compressImage(e.target.files[0]);toast("Photo attached","ok",1200);}};
  const rp=body.querySelector("#eRemovePhoto"); if(rp) rp.onclick=()=>{newPhoto="";rp.textContent="Photo will be removed";};
  modal({title:"Edit device",body,actions:[{label:"Delete",value:"delete",cls:"danger"},{label:"Cancel",value:null},{label:"Save",value:"save",cls:"primary"}]}).then(async r=>{
    if(r==="delete"){ if(await confirmBox("Delete device?",`Delete <b class="mono">${esc(d.serial||d.mac)}</b> (${esc(d.model||"")})? This can't be undone.`)){await DB.del("devices",d.id);S.devices=S.devices.filter(x=>x.id!==d.id);refreshAll();toast("Device deleted","ok");} return; }
    if(r!=="save") return;
    const g=s=>body.querySelector(s).value.trim();
    const upd={...d,serial:g("#eSerial").toUpperCase(),mac:UBNTParser.normMac(g("#eMac"))||g("#eMac").toUpperCase(),model:g("#eModel"),type:g("#eType"),location:g("#eLocation"),status:g("#eStatus"),installer:g("#eInstaller"),
      scannedAt:g("#eDate")?new Date(g("#eDate")).getTime():d.scannedAt,projectId:g("#eProject"),notes:g("#eNotes"),photo:newPhoto,updatedAt:Date.now()};
    const dup=findDuplicate(upd.serial,upd.mac,d.id);
    if(dup && !(await confirmBox("Duplicate",`Another device already has this serial/MAC (${esc(projLabel(project(dup.projectId)))}). Save anyway?`,"Save anyway","primary"))) return;
    await DB.put("devices",upd); S.devices[S.devices.findIndex(x=>x.id===d.id)]=upd; refreshAll(); toast("Device updated","ok");
  });
}

// ---------- projects ----------
function renderProjects(){
  const box=$("#projectList");
  if(!S.projects.length){box.innerHTML=`<div class="card empty">Create a project for each client and site (e.g. "Acme Corp · Main Office"). Every scan is saved to the active project.</div>`;return;}
  box.innerHTML=S.projects.map(p=>{const ds=devicesOf(p.id);const act=p.id===S.settings.activeProjectId;
    return `<div class="proj ${act?"active":""}" data-id="${p.id}">
      <div class="proj-top"><div><div class="proj-client">${esc(p.client)}</div><div class="proj-site">${esc(p.site||"")}${p.jobNumber?` · Job ${esc(p.jobNumber)}`:""}</div>
      ${p.address?`<div class="muted small">${esc(p.address)}</div>`:""}${p.contactName||p.contactEmail?`<div class="muted small">${esc(p.contactName||"")} ${esc(p.contactEmail||"")}</div>`:""}</div>
      <div class="proj-count">${ds.length}<small>devices</small></div></div>
      <div class="proj-actions">
        ${act?`<span class="tag s-Installed">Active</span>`:`<button class="btn small primary" data-act="activate">Make active</button>`}
        <button class="btn small" data-act="view">View devices</button>
        <button class="btn small" data-act="export">Export</button>
        <button class="btn small" data-act="edit">Edit</button>
        <button class="btn small danger" data-act="delete">Delete</button>
      </div></div>`;}).join("");
}
function projectForm(p={}){
  const b=document.createElement("div");
  b.innerHTML=`<label class="field"><span>Client / company *</span><input class="input" id="pClient" value="${esc(p.client||"")}" placeholder="e.g. Molekule Consulting"></label>
  <label class="field"><span>Site / job name</span><input class="input" id="pSite" value="${esc(p.site||"")}" placeholder="e.g. HQ 3rd floor install"></label>
  <div class="grid2"><label class="field"><span>Job / PO number</span><input class="input" id="pJob" value="${esc(p.jobNumber||"")}"></label>
  <label class="field"><span>Install date</span><input class="input" type="date" id="pDate" value="${esc(p.installDate||toLocalInput(new Date()).slice(0,10))}"></label>
  <label class="field"><span>Client contact</span><input class="input" id="pContact" value="${esc(p.contactName||"")}"></label>
  <label class="field"><span>Client email</span><input class="input" type="email" id="pEmail" value="${esc(p.contactEmail||"")}"></label></div>
  <label class="field"><span>Site address</span><input class="input" id="pAddress" value="${esc(p.address||"")}"></label>
  <label class="field"><span>Notes</span><textarea class="input" id="pNotes" rows="2">${esc(p.notes||"")}</textarea></label>`;
  return b;
}
async function editProject(p){
  const isNew=!p; const body=projectForm(p||{});
  const r=await modal({title:isNew?"New project":"Edit project",body,actions:[{label:"Cancel",value:null},{label:isNew?"Create":"Save",value:"ok",cls:"primary",validate:()=>{if(!body.querySelector("#pClient").value.trim()){toast("Client name is required","warn");return false;}return true;}}]});
  if(r!=="ok") return null;
  const g=s=>body.querySelector(s).value.trim();
  const rec={...(p||{id:uid(),createdAt:Date.now()}),client:g("#pClient"),site:g("#pSite"),jobNumber:g("#pJob"),installDate:g("#pDate"),contactName:g("#pContact"),contactEmail:g("#pEmail"),address:g("#pAddress"),notes:g("#pNotes"),updatedAt:Date.now()};
  await DB.put("projects",rec);
  const i=S.projects.findIndex(x=>x.id===rec.id); if(i>=0) S.projects[i]=rec; else S.projects.unshift(rec);
  if(isNew){S.settings.activeProjectId=rec.id;await saveSettings();}
  refreshAll(); toast(isNew?"Project created and set active":"Project saved","ok"); return rec.id;
}
async function deleteProject(p){
  const n=devicesOf(p.id).length;
  const body=document.createElement("div");
  body.innerHTML=`<p>Delete <b>${esc(projLabel(p))}</b>${n?` and its <b>${n}</b> device record${n>1?"s":""}`:""}? This can't be undone.</p>${n?`<p class="muted small">Tip: make a backup or export first.</p><label class="field"><span>Type DELETE to confirm</span><input class="input" id="delConfirm" autocapitalize="characters"></label>`:""}`;
  const r=await modal({title:"Delete project",body,actions:[{label:"Cancel",value:false},{label:"Delete",value:true,cls:"danger solid",validate:()=>{const i=body.querySelector("#delConfirm");if(i&&i.value.trim().toUpperCase()!=="DELETE"){toast("Type DELETE to confirm","warn");return false;}return true;}}]});
  if(!r) return;
  const ids=devicesOf(p.id).map(d=>d.id); await DB.bulkDel("devices",ids); await DB.del("projects",p.id);
  S.devices=S.devices.filter(d=>d.projectId!==p.id); S.projects=S.projects.filter(x=>x.id!==p.id);
  if(S.settings.activeProjectId===p.id){S.settings.activeProjectId="";await saveSettings();}
  refreshAll(); toast("Project deleted","ok");
}
async function pickProject(required){
  const body=document.createElement("div");
  body.innerHTML=(S.projects.length?S.projects.map(p=>`<button class="btn pick" data-id="${p.id}"><span>${esc(projLabel(p))}</span><span class="muted small">${devicesOf(p.id).length}</span></button>`).join(""):`<p class="muted">No projects yet.</p>`)+
    `<button class="btn primary pick" data-id="__new"><span>＋ New client / site</span></button>`+(required?`<button class="btn ghost pick" data-id="__none"><span>Save without a project</span></button>`:"");
  let chosen=null;
  const p=modal({title:"Active project",body,actions:[]});
  return new Promise(resolve=>{
    body.querySelectorAll("[data-id]").forEach(b=>b.onclick=async()=>{
      chosen=b.dataset.id; $("#modal").hidden=true;
      if(chosen==="__new"){const id=await editProject(null);resolve(id||"");return;}
      if(chosen==="__none"){resolve("");return;}
      S.settings.activeProjectId=chosen;await saveSettings();refreshAll();toast("Active: "+projLabel(project(chosen)),"ok",1500);resolve(chosen);
    });
    p.then(v=>{if(chosen===null) resolve(required?"":null);});
  });
}

// ---------- export ----------
const COLS=[["#","idx"],["Serial Number","serial"],["MAC Address","mac"],["Model","model"],["Device Type","type"],["Location","location"],["Status","status"],["Installer","installer"],["Date/Time","date"],["Client","client"],["Site","site"],["Notes","notes"]];
function exportRows(pid){
  const list=devicesOf(pid).slice().sort((a,b)=>(a.model||"").localeCompare(b.model||"")||(a.location||"").localeCompare(b.location||"")||a.scannedAt-b.scannedAt);
  return list.map((d,i)=>{const p=project(d.projectId);return {idx:i+1,serial:d.serial||"",mac:d.mac||"",model:d.model||"",type:d.type||"",location:d.location||"",status:d.status||"",installer:d.installer||"",date:fmtDate(d.scannedAt),dateShort:new Date(d.scannedAt).toLocaleDateString(undefined,{year:"2-digit",month:"numeric",day:"numeric"}),client:p?p.client:"",site:p?p.site||"":"",notes:d.notes||"",_photo:d.photo};});
}
function modelTotals(rows){const m={};rows.forEach(r=>{const k=r.model||"Unknown";m[k]=(m[k]||0)+1;});return Object.entries(m).sort((a,b)=>b[1]-a[1]);}
function typeTotals(rows){const m={};rows.forEach(r=>{const k=r.type||"Other";m[k]=(m[k]||0)+1;});return Object.entries(m).sort((a,b)=>b[1]-a[1]);}
function exportTitle(pid){const p=project(pid);return pid==="__all"?"All Projects":pid==="__none"?"Unassigned Devices":projLabel(p);}
function renderExportStats(){
  const pid=$("#exportProject").value||"__all"; const rows=exportRows(pid);
  const mt=modelTotals(rows);
  $("#exportStats").innerHTML=`<div class="stat"><b>${rows.length}</b><span>Devices</span></div><div class="stat"><b>${mt.length}</b><span>Models</span></div><div class="stat"><b>${new Set(rows.map(r=>r.location).filter(Boolean)).size}</b><span>Locations</span></div>`+
   (mt.length?`<div style="grid-column:1/-1" class="model-break">${mt.slice(0,8).map(([m,n])=>`${esc(m)} × ${n}`).join(" · ")}${mt.length>8?" …":""}</div>`:"");
}
function csvBlob(pid){
  const rows=exportRows(pid); const q=v=>{v=String(v==null?"":v);return /[",\n\r]/.test(v)?`"${v.replace(/"/g,'""')}"`:v;};
  const lines=[COLS.map(c=>q(c[0])).join(",")].concat(rows.map(r=>COLS.map(c=>q(r[c[1]])).join(",")));
  return new Blob(["\ufeff"+lines.join("\r\n")],{type:"text/csv;charset=utf-8"});
}
function xlsxBlob(pid){
  const rows=exportRows(pid); const s=S.settings; const p=project(pid);
  const wb=XLSX.utils.book_new();
  const head=[[s.company||"Device Inventory"],[`Client: ${exportTitle(pid)}`],[`Generated: ${fmtDate(Date.now())}`],[`Total devices: ${rows.length}`],[]];
  const data=head.concat([COLS.map(c=>c[0])],rows.map(r=>COLS.map(c=>r[c[1]])));
  const ws=XLSX.utils.aoa_to_sheet(data);
  ws["!cols"]=[{wch:5},{wch:18},{wch:19},{wch:22},{wch:18},{wch:22},{wch:11},{wch:16},{wch:20},{wch:22},{wch:22},{wch:36}];
  ws["!autofilter"]={ref:XLSX.utils.encode_range({s:{r:5,c:0},e:{r:5+rows.length,c:COLS.length-1}})};
  XLSX.utils.book_append_sheet(wb,ws,"Devices");
  const sum=[["Summary by model"],["Model","Quantity"]].concat(modelTotals(rows)).concat([["Total",rows.length],[],["Summary by type"],["Type","Quantity"]]).concat(typeTotals(rows));
  const ws2=XLSX.utils.aoa_to_sheet(sum); ws2["!cols"]=[{wch:30},{wch:10}]; XLSX.utils.book_append_sheet(wb,ws2,"Summary");
  if(p){const info=[["Client",p.client],["Site",p.site||""],["Job / PO",p.jobNumber||""],["Install date",p.installDate||""],["Contact",p.contactName||""],["Email",p.contactEmail||""],["Address",p.address||""],["Notes",p.notes||""],[],["Prepared by",s.company||""],["Phone",s.phone||""],["Email",s.email||""],["Website",s.website||""]];
    const ws3=XLSX.utils.aoa_to_sheet(info);ws3["!cols"]=[{wch:16},{wch:50}];XLSX.utils.book_append_sheet(wb,ws3,"Project");}
  const out=XLSX.write(wb,{bookType:"xlsx",type:"array"});
  return new Blob([out],{type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"});
}
async function pdfBlob(pid){
  const {jsPDF}=window.jspdf; const doc=new jsPDF({orientation:"portrait",unit:"pt",format:"letter"});
  const s=S.settings, p=project(pid), rows=exportRows(pid); const W=doc.internal.pageSize.getWidth(), M=40; const blue=[10,102,232];
  let y=M;
  if(s.logo){try{const img=await new Promise((res,rej)=>{const i=new Image();i.onload=()=>res(i);i.onerror=rej;i.src=s.logo;});const h=46,w=Math.min(160,img.width*h/img.height);doc.addImage(s.logo,s.logo.includes("image/png")?"PNG":"JPEG",M,y,w,h);}catch(e){}}
  doc.setFont("helvetica","bold");doc.setFontSize(13);doc.setTextColor(20);doc.text(s.company||"",W-M,y+12,{align:"right"});
  doc.setFont("helvetica","normal");doc.setFontSize(8.5);doc.setTextColor(90);
  [s.address,[s.phone,s.email].filter(Boolean).join("  ·  "),s.website].filter(Boolean).forEach((l,i)=>doc.text(l,W-M,y+26+i*11,{align:"right"}));
  y+=62; doc.setDrawColor(...blue);doc.setLineWidth(2.5);doc.line(M,y,W-M,y); y+=24;
  doc.setTextColor(15);doc.setFont("helvetica","bold");doc.setFontSize(18);doc.text("Device Installation Report",M,y); y+=20;
  doc.setFontSize(10);doc.setFont("helvetica","normal");doc.setTextColor(60);
  const meta=[["Client",p?p.client:exportTitle(pid)],["Site",p&&p.site||""],["Job / PO",p&&p.jobNumber||""],["Install date",p&&p.installDate?fmtDay(p.installDate+"T12:00"):""],["Contact",p?[p.contactName,p.contactEmail].filter(Boolean).join(" · "):""],["Address",p&&p.address||""],["Report date",fmtDay(Date.now())],["Total devices",String(rows.length)]].filter(m=>m[1]);
  const colW=(W-2*M)/2;
  meta.forEach((m,i)=>{const x=M+(i%2)*colW,yy=y+Math.floor(i/2)*15;doc.setFont("helvetica","bold");doc.setTextColor(40);doc.text(m[0]+":",x,yy);doc.setFont("helvetica","normal");doc.setTextColor(70);doc.text(doc.splitTextToSize(m[1],colW-80)[0],x+72,yy);});
  y+=Math.ceil(meta.length/2)*15+10;
  // summary table
  doc.setFont("helvetica","bold");doc.setFontSize(12);doc.setTextColor(10,61,143);doc.text("Summary by model",M,y);y+=6;
  doc.autoTable({startY:y,margin:{left:M,right:M},head:[["Model","Type","Qty"]],body:modelTotals(rows).map(([m,n])=>{const r=rows.find(x=>(x.model||"Unknown")===m);return [m,r&&r.type||"",String(n)];}).concat([[{content:"Total",styles:{fontStyle:"bold"}},"",{content:String(rows.length),styles:{fontStyle:"bold"}}]]),
    theme:"grid",headStyles:{fillColor:blue,textColor:255,fontSize:9},styles:{fontSize:9,cellPadding:4},columnStyles:{2:{halign:"right",cellWidth:50}},tableWidth:340});
  y=doc.lastAutoTable.finalY+20;
  doc.setFont("helvetica","bold");doc.setFontSize(12);doc.setTextColor(10,61,143);doc.text("Device list",M,y);y+=6;
  doc.autoTable({startY:y,margin:{left:M,right:M,bottom:50},head:[["#","Serial number","MAC address","Model","Location","Status","Date"]],
    body:rows.map(r=>[r.idx,r.serial,r.mac,r.model,r.location,r.status,r.dateShort]),
    theme:"striped",headStyles:{fillColor:blue,textColor:255,fontSize:8.5},styles:{fontSize:8.2,cellPadding:3.5,overflow:"linebreak",textColor:25},alternateRowStyles:{fillColor:[244,247,252]},
    columnStyles:{0:{cellWidth:22,halign:"right"},1:{font:"courier",cellWidth:92},2:{font:"courier",cellWidth:98},5:{cellWidth:52},6:{cellWidth:52}}});
  y=doc.lastAutoTable.finalY+18;
  const notesRows=rows.filter(r=>r.notes);
  if(notesRows.length){doc.autoTable({startY:y,margin:{left:M,right:M,bottom:50},head:[["#","Serial","Notes"]],body:notesRows.map(r=>[r.idx,r.serial,r.notes]),theme:"plain",headStyles:{textColor:[10,61,143],fontSize:9},styles:{fontSize:8.2,cellPadding:3},columnStyles:{0:{cellWidth:22},1:{font:"courier",cellWidth:92}}});y=doc.lastAutoTable.finalY+18;}
  if(p&&p.notes){doc.setFont("helvetica","bold");doc.setFontSize(10);doc.setTextColor(40);if(y>680){doc.addPage();y=M;}doc.text("Project notes",M,y);y+=13;doc.setFont("helvetica","normal");doc.setFontSize(9);doc.setTextColor(70);const ls=doc.splitTextToSize(p.notes,W-2*M);doc.text(ls,M,y);y+=ls.length*11+10;}
  if(y>660){doc.addPage();y=M;}
  y+=30;doc.setDrawColor(80);doc.setLineWidth(0.6);doc.line(M,y,M+220,y);doc.line(W-M-220,y,W-M,y);doc.setFontSize(8.5);doc.setTextColor(80);doc.text("Installer signature / date",M,y+12);doc.text("Client signature / date",W-M-220,y+12);
  const pages=doc.getNumberOfPages();
  for(let i=1;i<=pages;i++){doc.setPage(i);doc.setFontSize(7.5);doc.setTextColor(120);const H=doc.internal.pageSize.getHeight();
    if(s.footer) doc.text(doc.splitTextToSize(s.footer,W-2*M-60),M,H-26);
    doc.text(`Page ${i} of ${pages}`,W-M,H-26,{align:"right"});}
  return doc.output("blob");
}
async function makeFile(kind,pid){
  const base=`${slug(exportTitle(pid))}-devices-${fileStamp()}`;
  if(kind==="csv") return new File([csvBlob(pid)],base+".csv",{type:"text/csv"});
  if(kind==="xlsx") return new File([xlsxBlob(pid)],base+".xlsx",{type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"});
  if(kind==="pdf") return new File([await pdfBlob(pid)],`${slug(exportTitle(pid))}-report-${fileStamp()}.pdf`,{type:"application/pdf"});
  if(kind==="backup") return new File([JSON.stringify(await backupData(),null,1)],`sn-scanner-backup-${fileStamp()}.json`,{type:"application/json"});
}
function download(file){const a=document.createElement("a");a.href=URL.createObjectURL(file);a.download=file.name;document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove();},4000);}
async function doExport(kind,share){
  const pid=$("#exportProject").value||"__all";
  if(kind!=="backup" && !devicesOf(pid).length){toast("No devices in this selection yet","warn");return;}
  try{
    const file=await makeFile(kind,pid);
    if(share){
      if(navigator.canShare && navigator.canShare({files:[file]})){
        try{await navigator.share({files:[file],title:file.name,text:kind==="backup"?"SN Scanner backup":`Device list: ${exportTitle(pid)} (${devicesOf(pid).length} devices)`});}
        catch(e){if(e.name!=="AbortError"){download(file);toast("Sharing failed, file downloaded instead","warn");}}
      } else {download(file);toast("This browser can't share files. Downloaded instead; attach it from Downloads.","warn",4500);}
    } else {download(file);toast("Saved "+file.name,"ok");}
  }catch(e){console.error(e);toast("Export failed: "+(e.message||e),"bad",5000);}
}
function mailtoSummary(){
  const pid=$("#exportProject").value||"__all"; const rows=exportRows(pid); const p=project(pid);
  if(!rows.length){toast("No devices in this selection yet","warn");return;}
  const lines=[`Hi${p&&p.contactName?" "+p.contactName.split(" ")[0]:""},`,"",`Here is the device list for ${exportTitle(pid)} (${rows.length} devices):`,""]
    .concat(modelTotals(rows).map(([m,n])=>`- ${m}: ${n}`)).concat(["","Serial / MAC / Model / Location:"]).concat(rows.slice(0,60).map(r=>`${r.idx}. ${r.serial}${r.mac&&r.mac.replace(/:/g,"")!==r.serial?" / "+r.mac:""} / ${r.model} / ${r.location}`))
    .concat(rows.length>60?["(full list in the attached spreadsheet)"]:[]).concat(["","Thank you,",S.settings.installer||"",S.settings.company||""]);
  const subj=`Device inventory - ${exportTitle(pid)}`;
  let body=lines.join("\n"); if(body.length>1800) body=body.slice(0,1800)+"\n…";
  location.href=`mailto:${encodeURIComponent(p&&p.contactEmail||"")}?subject=${encodeURIComponent(subj)}&body=${encodeURIComponent(body)}`;
}
function previewReport(){
  const pid=$("#exportProject").value||"__all"; const rows=exportRows(pid); const s=S.settings; const p=project(pid);
  if(!rows.length){toast("No devices in this selection yet","warn");return;}
  $("#printReport").innerHTML=`<div class="rep">
   <div class="rep-head"><div>${s.logo?`<img src="${s.logo}">`:""}<h1>Device Installation Report</h1></div><div class="co"><b>${esc(s.company)}</b><br>${esc(s.address)}<br>${esc([s.phone,s.email].filter(Boolean).join(" · "))}<br>${esc(s.website)}</div></div>
   <div class="rep-meta"><div><b>Client:</b> ${esc(p?p.client:exportTitle(pid))}</div><div><b>Site:</b> ${esc(p&&p.site||"")}</div><div><b>Job / PO:</b> ${esc(p&&p.jobNumber||"")}</div><div><b>Report date:</b> ${esc(fmtDay(Date.now()))}</div><div><b>Address:</b> ${esc(p&&p.address||"")}</div><div><b>Total devices:</b> ${rows.length}</div></div>
   <h2>Summary by model</h2><table><tr><th>Model</th><th>Qty</th></tr>${modelTotals(rows).map(([m,n])=>`<tr><td>${esc(m)}</td><td>${n}</td></tr>`).join("")}<tr><td><b>Total</b></td><td><b>${rows.length}</b></td></tr></table>
   <h2>Device list</h2><table><tr><th>#</th><th>Serial</th><th>MAC</th><th>Model</th><th>Location</th><th>Status</th><th>Date</th><th>Notes</th></tr>
   ${rows.map(r=>`<tr><td>${r.idx}</td><td class="mono">${esc(r.serial)}</td><td class="mono">${esc(r.mac)}</td><td>${esc(r.model)}</td><td>${esc(r.location)}</td><td>${esc(r.status)}</td><td>${esc(r.date)}</td><td>${esc(r.notes)}</td></tr>`).join("")}</table>
   <div class="sig"><div>Installer signature / date</div><div>Client signature / date</div></div>
   <div class="rep-foot">${esc(s.footer)}</div></div>`;
  setTimeout(()=>window.print(),100);
}

// ---------- backup / restore / import ----------
async function backupData(){return {app:"ubnt-sn-scanner",version:APP_VERSION,exportedAt:new Date().toISOString(),settings:S.settings,projects:S.projects,devices:S.devices};}
async function restore(file){
  try{
    const j=JSON.parse(await readFileAsText(file));
    if(j.app!=="ubnt-sn-scanner"||!Array.isArray(j.devices)) throw new Error("Not an SN Scanner backup file");
    const mode=await modal({title:"Restore backup",body:`<p>Backup from ${esc(fmtDate(j.exportedAt))}: <b>${j.projects.length}</b> projects, <b>${j.devices.length}</b> devices.</p><p class="muted">Merge keeps your current data and adds/updates from the backup. Replace deletes everything on this phone first.</p>`,
      actions:[{label:"Cancel",value:null},{label:"Replace all",value:"replace",cls:"danger"},{label:"Merge",value:"merge",cls:"primary"}]});
    if(!mode) return;
    if(mode==="replace"){ if(!(await confirmBox("Replace all data?","Everything currently on this phone will be deleted and replaced by the backup.","Replace"))) return; await DB.clear("devices");await DB.clear("projects"); }
    await DB.bulkPut("projects",j.projects); await DB.bulkPut("devices",j.devices);
    if(j.settings && mode==="replace"){S.settings={...DEFAULT_SETTINGS,...j.settings};await saveSettings();}
    await load(); applyTheme();applyBrand();refreshAll(); toast(`Restored ${j.devices.length} devices`,"ok");
  }catch(e){toast("Restore failed: "+e.message,"bad",5000);}
}
function parseCSV(text){
  const rows=[];let row=[],f="",q=false;text=text.replace(/^\ufeff/,"");
  for(let i=0;i<text.length;i++){const c=text[i];
    if(q){if(c==='"'){if(text[i+1]==='"'){f+='"';i++;}else q=false;}else f+=c;}
    else if(c==='"')q=true; else if(c===","){row.push(f);f="";} else if(c==="\n"||c==="\r"){if(c==="\r"&&text[i+1]==="\n")i++;row.push(f);rows.push(row);row=[];f="";} else f+=c;}
  if(f||row.length){row.push(f);rows.push(row);} return rows.filter(r=>r.some(x=>x.trim()));
}
async function importCsv(file){
  try{
    const rows=parseCSV(await readFileAsText(file)); if(rows.length<2) throw new Error("CSV is empty");
    const h=rows[0].map(x=>x.toLowerCase().trim()); const col=(...names)=>h.findIndex(x=>names.some(n=>x.includes(n)));
    const ci={serial:col("serial","s/n","sn"),mac:col("mac"),model:col("model","sku"),type:col("type"),location:col("location","room"),status:col("status"),installer:col("installer","tech"),notes:col("note"),date:col("date")};
    if(ci.serial<0&&ci.mac<0) throw new Error("CSV needs a Serial or MAC column");
    const pid=await ensureProject(); let added=0,skipped=0; const recs=[];
    for(const r of rows.slice(1)){
      const g=k=>ci[k]>=0?(r[ci[k]]||"").trim():"";
      const mac=UBNTParser.normMac(g("mac"))||g("mac").toUpperCase(); let serial=g("serial").toUpperCase(); if(!serial&&mac&&S.settings.serialFromMac) serial=mac.replace(/:/g,"");
      if(!serial&&!mac) continue;
      if(findDuplicate(serial,mac)||recs.find(x=>(serial&&x.serial===serial)||(mac&&x.mac===mac))){skipped++;continue;}
      const fm=UBNTParser.findModel(g("model")); const dt=Date.parse(g("date"));
      recs.push({id:uid(),projectId:pid,serial,mac,model:g("model"),type:g("type")||(fm?fm.type:""),location:g("location"),status:g("status")||"Installed",installer:g("installer"),notes:g("notes"),scannedAt:isNaN(dt)?Date.now():dt,photo:"",raw:"csv import",createdAt:Date.now(),updatedAt:Date.now()});added++;
    }
    await DB.bulkPut("devices",recs); S.devices.push(...recs); refreshAll(); toast(`Imported ${added} devices${skipped?`, skipped ${skipped} duplicates`:""}`,"ok",4000);
  }catch(e){toast("Import failed: "+e.message,"bad",5000);}
}

// ---------- settings ----------
function renderSettings(){
  const s=S.settings;
  $("#sCompany").value=s.company;$("#sPhone").value=s.phone;$("#sEmail").value=s.email;$("#sWebsite").value=s.website;$("#sInstaller").value=s.installer;$("#sAddress").value=s.address;$("#sFooter").value=s.footer;
  $("#sTheme").value=s.theme;$("#sBeep").checked=s.beep;$("#sVibrate").checked=s.vibrate;$("#sSerialFromMac").checked=s.serialFromMac;$("#sCustomModels").value=s.customModels;
  const lp=$("#sLogoPreview");lp.hidden=!s.logo;if(s.logo)lp.src=s.logo;$("#btnRemoveLogo").hidden=!s.logo;
  $("#btnInstall").hidden=!S.deferredInstall;
  navigator.storage&&navigator.storage.estimate&&navigator.storage.estimate().then(e=>{$("#versionInfo").textContent=`SN Scanner v${APP_VERSION} · ${S.devices.length} devices · ${(e.usage/1048576).toFixed(1)} MB used on this device`;});
}
async function saveSettingsForm(){
  Object.assign(S.settings,{company:$("#sCompany").value.trim(),phone:$("#sPhone").value.trim(),email:$("#sEmail").value.trim(),website:$("#sWebsite").value.trim(),installer:$("#sInstaller").value.trim(),address:$("#sAddress").value.trim(),footer:$("#sFooter").value.trim(),
    theme:$("#sTheme").value,beep:$("#sBeep").checked,vibrate:$("#sVibrate").checked,serialFromMac:$("#sSerialFromMac").checked,customModels:$("#sCustomModels").value});
  window.CUSTOM_MODELS=S.settings.customModels.split("\n").map(s=>s.trim()).filter(Boolean);
  await saveSettings(); applyTheme(); applyBrand(); refreshPicklists(); if(!$("#fInstaller").value) $("#fInstaller").value=S.settings.installer; toast("Settings saved","ok");
}

// ---------- wire up ----------
function bind(){
  $$(".tabbar button").forEach(b=>b.onclick=()=>show(b.dataset.view));
  $("#projectPill").onclick=()=>pickProject(false);
  $("#btnStartScan").onclick=startScan; $("#btnStopScan").onclick=stopScan; $("#btnTorch").onclick=toggleTorch;
  $("#cameraSelect").onchange=async()=>{if(S.scanning){await stopScan();startScan();}};
  $("#zoom").oninput=e=>{$("#zoomVal").textContent=Number(e.target.value).toFixed(1)+"×";S.scanner&&S.scanner.setZoom(Number(e.target.value)).catch(()=>{});};
  $("#scanFile").onchange=e=>{scanFromFile(e.target.files[0]);e.target.value="";};
  $("#optContinuous").onchange=e=>{S.settings.continuous=e.target.checked;saveSettings();if(e.target.checked)toast("Continuous: each serial/MAC scan saves automatically","ok",3000);};
  $("#optKeepFields").onchange=e=>{S.settings.keepFields=e.target.checked;saveSettings();};
  $("#btnSave").onclick=()=>saveDevice(); $("#btnClearForm").onclick=()=>{clearForm(false);$("#lastScan").hidden=true;};
  $("#fSerial").addEventListener("keydown",e=>{if(e.key==="Enter"){e.preventDefault();saveDevice();}}); // works with Bluetooth/USB scanners in keyboard mode
  $("#fSerial").addEventListener("change",()=>{const v=$("#fSerial").value.trim();if(v.length>14&&/[\s,;:]/.test(v)){const t=v;$("#fSerial").value="";handleScan(t,"");}});
  $("#fMac").addEventListener("blur",()=>{const m=UBNTParser.normMac($("#fMac").value);if(m)$("#fMac").value=m;});
  $("#fModel").addEventListener("change",()=>{const fm=UBNTParser.findModel($("#fModel").value);if(fm&&!$("#fType").value)$("#fType").value=fm.type; const ex=window.UBNT_MODELS.find(m=>m[0].toLowerCase()===$("#fModel").value.trim().toLowerCase());if(ex)$("#fType").value=ex[2];});
  $("#fPhoto").onchange=async e=>{if(e.target.files[0]){setPhoto(await compressImage(e.target.files[0]));} e.target.value="";};
  $("#btnRemovePhoto").onclick=()=>setPhoto("");
  ["#search","#filterProject","#filterType","#filterStatus","#sortBy"].forEach(s=>$(s).addEventListener("input",renderDevices));
  $("#deviceList").onclick=e=>{const d=e.target.closest(".dev");if(d)editDevice(d.dataset.id);};
  $("#btnNewProject").onclick=()=>editProject(null);
  $("#projectList").onclick=async e=>{const b=e.target.closest("[data-act]");if(!b)return;const p=project(b.closest(".proj").dataset.id);
    const a=b.dataset.act;
    if(a==="activate"){S.settings.activeProjectId=p.id;await saveSettings();refreshAll();toast("Active: "+projLabel(p),"ok",1500);}
    if(a==="edit") editProject(p); if(a==="delete") deleteProject(p);
    if(a==="view"){show("devices");$("#filterProject").value=p.id;renderDevices();}
    if(a==="export"){show("export");$("#exportProject").value=p.id;renderExportStats();}};
  $("#exportProject").onchange=renderExportStats;
  $$("[data-export]").forEach(b=>b.onclick=()=>doExport(b.dataset.export,false));
  $$("[data-share]").forEach(b=>b.onclick=()=>doExport(b.dataset.share,true));
  $("#btnPreview").onclick=previewReport; $("#btnMailto").onclick=mailtoSummary;
  $("#btnBackup").onclick=()=>doExport("backup",false); $("#btnShareBackup").onclick=()=>doExport("backup",true);
  $("#restoreFile").onchange=e=>{if(e.target.files[0])restore(e.target.files[0]);e.target.value="";};
  $("#importCsv").onchange=e=>{if(e.target.files[0])importCsv(e.target.files[0]);e.target.value="";};
  $("#btnSaveSettings").onclick=saveSettingsForm;
  $("#sTheme").onchange=()=>{S.settings.theme=$("#sTheme").value;applyTheme();};
  $("#sLogo").onchange=async e=>{const f=e.target.files[0];if(!f)return;S.settings.logo=await compressImage(f,600,0.9);if(f.type==="image/png"){S.settings.logo=await readFileAsDataURL(f);if(S.settings.logo.length>700000)S.settings.logo=await compressImage(f,600,0.9);}await saveSettings();applyBrand();renderSettings();toast("Logo saved","ok");e.target.value="";};
  $("#btnRemoveLogo").onclick=async()=>{S.settings.logo="";await saveSettings();applyBrand();renderSettings();};
  $("#btnWipe").onclick=async()=>{const body=document.createElement("div");body.innerHTML=`<p>This deletes <b>all ${S.devices.length} devices and ${S.projects.length} projects</b> on this phone. Make a backup first.</p><label class="field"><span>Type DELETE to confirm</span><input class="input" id="wipeConfirm"></label>`;
    const r=await modal({title:"Delete all data",body,actions:[{label:"Cancel",value:false},{label:"Delete everything",value:true,cls:"danger solid",validate:()=>body.querySelector("#wipeConfirm").value.trim().toUpperCase()==="DELETE"||(toast("Type DELETE to confirm","warn"),false)}]});
    if(!r)return; await DB.clear("devices");await DB.clear("projects");S.devices=[];S.projects=[];S.settings.activeProjectId="";await saveSettings();refreshAll();toast("All data deleted","ok");};
  matchMedia("(prefers-color-scheme: dark)").addEventListener("change",applyTheme);
  window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();S.deferredInstall=e;$("#btnInstall").hidden=false;});
  $("#btnInstall").onclick=async()=>{if(!S.deferredInstall)return;S.deferredInstall.prompt();await S.deferredInstall.userChoice;S.deferredInstall=null;$("#btnInstall").hidden=true;};
  document.addEventListener("visibilitychange",()=>{if(document.hidden&&S.scanning)stopScan();});
}

async function init(){
  await load(); applyTheme(); applyBrand(); bind(); refreshAll();
  $("#optContinuous").checked=S.settings.continuous; $("#optKeepFields").checked=S.settings.keepFields;
  clearForm(false);
  if("serviceWorker" in navigator && (location.protocol==="https:"||location.hostname==="localhost")) navigator.serviceWorker.register("sw.js").catch(()=>{});
  window.__app={S,handleScan,saveDevice,makeFile,exportRows,pdfBlob,xlsxBlob,csvBlob,editProject,DB};
}
init().catch(e=>{console.error(e);document.body.insertAdjacentHTML("afterbegin",`<div style="padding:12px;background:#b91c1c;color:#fff">Startup error: ${esc(e.message)}</div>`);});
})();
