// Parses raw barcode / QR text from Ubiquiti labels into {serial, mac, model, upc, kind}
(function(){
  const HEX12 = /^[0-9A-F]{12}$/i;
  const MAC_SEP = /\b([0-9A-F]{2}[:\-.]){5}[0-9A-F]{2}\b/i;
  const MAC_DOT = /\b[0-9A-F]{4}\.[0-9A-F]{4}\.[0-9A-F]{4}\b/i;
  // Common Ubiquiti OUIs (used only to prefer a candidate when several hex tokens appear)
  const UBNT_OUI = ["245A4C","788A20","7483C2","F09FC2","802AA8","18E829","B4FBE4","68D79A","E063DA","FCECDA","70A741","D021F9","AC8BA9","0CEA14","6C63F8","9C05D6","1C6A1B","28704E","602232","58D61F","D8B370","E43883","847848","942A6F","F4E2C6","44D9E7","0418D6","24A43C","DC9FDB","002722","00156D","687251","784558","E438834","D8B370","F492BF","1C0B8B","8C3066","9CB2E8","A89C6C","28AF42"];
  function normMac(s){
    const h = String(s||"").replace(/[^0-9A-F]/gi,"").toUpperCase();
    if(h.length!==12) return "";
    return h.match(/.{2}/g).join(":");
  }
  function isUbntOui(mac){ const h=mac.replace(/:/g,""); return UBNT_OUI.some(o=>h.startsWith(o.slice(0,6))); }
  function modelIndex(){
    const list=(window.UBNT_MODELS||[]).concat((window.CUSTOM_MODELS||[]).map(m=>[m,m,""]));
    const idx=[];
    for(const [name,sku,type] of list){
      if(sku) idx.push({key:sku.toUpperCase(),name,type});
      idx.push({key:name.toUpperCase().replace(/\s+/g,"-"),name,type});
    }
    return idx.sort((a,b)=>b.key.length-a.key.length);
  }
  function findModel(text){
    if(!text) return null;
    const T = " "+String(text).toUpperCase().replace(/[_\s]+/g,"-")+" ";
    for(const m of modelIndex()){
      if(m.key.length<3) continue;
      const i=T.indexOf(m.key);
      if(i<0) continue;
      const before=T[i-1], after=T[i+m.key.length];
      const okB = !before || /[^A-Z0-9]/.test(before);
      // allow region suffix like -US / -EU, but not a longer model continuing (e.g. U6-LR vs U6-LR-XYZ handled by longest-first)
      const okA = !after || /[^A-Z0-9]/.test(after);
      if(okB&&okA) return m;
    }
    return null;
  }
  function kv(text){
    const out={};
    // URL query params
    try{
      if(/^https?:\/\//i.test(text)){
        const u=new URL(text);
        u.searchParams.forEach((v,k)=>{out[k.toLowerCase()]=v;});
        const segs=u.pathname.split("/").filter(Boolean); out._path=segs;
      }
    }catch(e){}
    // JSON
    if(/^\s*\{/.test(text)){ try{ const j=JSON.parse(text); for(const k in j) out[k.toLowerCase()]=String(j[k]); }catch(e){} }
    // key: value / key=value pairs
    const re=/(S\/N|SN|SER(?:IAL)?(?:\s*(?:NO|NUMBER|#))?|MAC(?:\s*ADDR(?:ESS)?)?|MODEL|SKU|P\/N|PN|PART(?:\s*NO)?|UPC|EAN)\s*[:=#]\s*([A-Z0-9:\-._\/]+)/gi;
    let m; while((m=re.exec(text))){ out[m[1].toLowerCase().replace(/[^a-z]/g,"")]=m[2]; }
    return out;
  }
  function parse(raw, format){
    const text=String(raw||"").trim();
    const res={raw:text,format:format||"",serial:"",mac:"",model:"",type:"",upc:"",kind:"unknown"};
    if(!text) return res;
    const f=(format||"").toUpperCase();
    if(/^(UPC_A|UPC_E|EAN_13|EAN_8)$/.test(f) || (/^\d{12,14}$/.test(text) && /^(81|0?81|0?85|0?89)/.test(text) && f!=="CODE_128")){
      res.upc=text; res.kind="upc";
      return res;
    }
    const k=kv(text);
    const mv = k.mac||k.macaddr||k.macaddress||k.m;
    if(mv && normMac(mv)) res.mac=normMac(mv);
    const sv = k.sn||k.serial||k.serialno||k.serialnumber||k.sernumber||k.s||k.id;
    if(sv) res.serial=String(sv).toUpperCase().replace(/[^A-Z0-9\-]/g,"");
    const mdl = k.model||k.sku||k.pn||k.partno||k.part;
    if(mdl){ const fm=findModel(mdl); res.model=fm?fm.name:mdl; if(fm) res.type=fm.type; }
    if(k.upc||k.ean) res.upc=k.upc||k.ean;
    // Free-form tokens
    const tokens=text.split(/[\s,;|\t\r\n]+|(?<=[A-Z0-9])\/(?=[A-Z0-9])/i).map(t=>t.replace(/^[^A-Z0-9]+|[^A-Z0-9]+$/gi,"")).filter(Boolean);
    if(!res.mac){
      const ms=text.match(MAC_SEP)||text.match(MAC_DOT);
      if(ms) res.mac=normMac(ms[0]);
      else{
        const hex=tokens.filter(t=>HEX12.test(t) && /[A-F]/i.test(t) || (HEX12.test(t) && tokens.length>1));
        const hexAll=tokens.filter(t=>HEX12.test(t));
        const cand=hexAll.map(normMac);
        const pick=cand.find(isUbntOui)||cand[0];
        if(pick) res.mac=pick;
      }
    }
    if(!res.model){ const fm=findModel(text); if(fm){res.model=fm.name;res.type=fm.type;} }
    else if(!res.type){ const fm=findModel(res.model); if(fm) res.type=fm.type; }
    if(!res.serial){
      // A token that is not the MAC, not a model code, not a URL piece, 6-24 chars, has digits
      const macHex=res.mac.replace(/:/g,"");
      const fm=res.model?findModel(res.model):null;
      const cands=tokens.filter(t=>{
        const u=t.toUpperCase();
        if(u.replace(/[^0-9A-F]/g,"")===macHex && macHex) return false;
        if(fm && (u.includes(fm.key)||fm.key.includes(u))) return false;
        if(findModel(u)) return false;
        if(/^HTTPS?$/i.test(u)||u.includes(".")) return false;
        return /^[A-Z0-9\-]{6,24}$/.test(u) && /\d/.test(u);
      });
      if(cands.length===1 || (cands.length>1 && !res.mac)) res.serial=cands[0].toUpperCase();
    }
    if(res.serial && res.mac && res.serial===res.mac.replace(/:/g,"")) res.kind="mac-serial";
    else if(res.serial||res.mac) res.kind = res.serial&&res.mac?"full":(res.mac?"mac":"serial");
    else if(res.model) res.kind="model";
    return res;
  }
  window.UBNTParser={parse,normMac,findModel};
})();
