// Tiny IndexedDB wrapper
(function(){
  const NAME="ubnt-sn-scanner", VER=1; let dbp=null;
  function open(){
    if(dbp) return dbp;
    dbp=new Promise((res,rej)=>{
      const r=indexedDB.open(NAME,VER);
      r.onupgradeneeded=()=>{
        const db=r.result;
        if(!db.objectStoreNames.contains("projects")) db.createObjectStore("projects",{keyPath:"id"});
        if(!db.objectStoreNames.contains("devices")){
          const s=db.createObjectStore("devices",{keyPath:"id"});
          s.createIndex("projectId","projectId"); s.createIndex("serial","serial"); s.createIndex("mac","mac");
        }
        if(!db.objectStoreNames.contains("kv")) db.createObjectStore("kv");
      };
      r.onsuccess=()=>res(r.result); r.onerror=()=>rej(r.error);
    });
    return dbp;
  }
  function tx(store,mode,fn){
    return open().then(db=>new Promise((res,rej)=>{
      const t=db.transaction(store,mode); const s=t.objectStore(store); let out;
      Promise.resolve(fn(s)).then(v=>{out=v;});
      t.oncomplete=()=>res(out); t.onerror=()=>rej(t.error); t.onabort=()=>rej(t.error);
    }));
  }
  const req=r=>new Promise((res,rej)=>{r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error);});
  window.DB={
    all:(store)=>tx(store,"readonly",s=>req(s.getAll())),
    get:(store,key)=>tx(store,"readonly",s=>req(s.get(key))),
    put:(store,val,key)=>tx(store,"readwrite",s=>req(key!==undefined?s.put(val,key):s.put(val))),
    del:(store,key)=>tx(store,"readwrite",s=>req(s.delete(key))),
    clear:(store)=>tx(store,"readwrite",s=>req(s.clear())),
    bulkPut:(store,vals)=>tx(store,"readwrite",s=>{vals.forEach(v=>s.put(v));}),
    bulkDel:(store,keys)=>tx(store,"readwrite",s=>{keys.forEach(k=>s.delete(k));}),
  };
  if(navigator.storage && navigator.storage.persist) navigator.storage.persist().catch(()=>{});
})();
