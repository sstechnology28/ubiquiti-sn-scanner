# SN Scanner · Ubiquiti Asset Inventory
Phone-first PWA for Specialized Security Technology: scan Ubiquiti serials/MACs, organize by client/site, export CSV / Excel / PDF report, share from the phone.

Hosting: GitHub Pages → Settings → Pages → Deploy from branch `main` / root.
All data stays on the device (IndexedDB). Use Export → Backup regularly.
When updating files, bump the cache name in `sw.js` so phones pick up the new version.
